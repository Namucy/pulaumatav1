package com.akbar.pulaumata

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.view.View
import kotlin.random.Random

/** Mata hitam lucu: berkedip, melirik, dan sesekali tersenyum. */
class EyesView(c: Context) : View(c) {
    private val black = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF0A0A0A.toInt() }
    private val spark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private var look = 0f
    private var blink = 1f
    private val h = Handler(Looper.getMainLooper())
    private val loop = object : Runnable {
        override fun run() {
            if (Random.nextInt(3) == 0) doBlink() else lookTo(Random.nextFloat() * 2 - 1)
            h.postDelayed(this, Random.nextLong(1500, 3800))
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); h.postDelayed(loop, 900) }
    override fun onDetachedFromWindow() { h.removeCallbacks(loop); super.onDetachedFromWindow() }

    private fun doBlink() {
        ValueAnimator.ofFloat(1f, 0.1f, 1f).apply {
            duration = 240
            addUpdateListener { blink = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun lookTo(t: Float) {
        ValueAnimator.ofFloat(look, t).apply {
            duration = 280
            addUpdateListener { look = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val hh = height.toFloat()
        val ew = hh * 0.42f
        val eh = hh * 0.66f * blink
        val shift = look * w * 0.05f
        for (cx in floatArrayOf(w * 0.38f + shift, w * 0.62f + shift)) {
            c.drawOval(cx - ew / 2, hh / 2 - eh / 2, cx + ew / 2, hh / 2 + eh / 2, black)
            if (blink > 0.5f) c.drawCircle(cx - ew * 0.15f, hh / 2 - eh * 0.2f, ew * 0.17f, spark)
        }
    }
}

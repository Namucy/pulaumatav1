package com.akbar.pulaumata

import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.app.ActivityOptions
import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable
import android.graphics.drawable.BitmapDrawable
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.RingtoneManager
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

class IslandService : AccessibilityService() {

    companion object {
        var instance: IslandService? = null
        var controllers: List<MediaController> = emptyList()
        const val USE_BLUR = false // true = coba blur latar asli (sudut bisa terlihat persegi)
    }

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var island: FrameLayout
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var glass: GlassDrawable
    private var sizeAnim: ValueAnimator? = null
    private var currentKey = ""

    private var expanded = false
    private var replying = false
    private var tempView: View? = null
    private var tempKey = ""
    private var lastPkg = ""

    private var media: MediaController? = null
    private var timerEnd = 0L
    private var timerLabel: TextView? = null
    private var panelTimerLabel: TextView? = null
    private var progressBar: ProgressBar? = null
    private var live: StatusBarNotification? = null
    private var liveView: View? = null
    private var audioReady = false
    private val audio by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- siklus hidup ----------
    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        glass = GlassDrawable(resources.displayMetrics.density)
        island = FrameLayout(this).apply {
            background = glass
            setOnClickListener { toggleExpanded() }
            setOnTouchListener { _, ev ->
                if (ev.action == MotionEvent.ACTION_OUTSIDE && expanded && !replying) {
                    expanded = false; ui.removeCallbacks(autoCollapse); refresh()
                }
                false
            }
        }
        lp = WindowManager.LayoutParams(
            dp(110), dp(32),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(8)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        }
        if (USE_BLUR && Build.VERSION.SDK_INT >= 31) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = dp(24)
        }
        wm.addView(island, lp)

        val f = IntentFilter().apply {
            addAction("android.media.VOLUME_CHANGED_ACTION")
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_BATTERY_LOW)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(sysReceiver, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(sysReceiver, f)

        audio.registerAudioDeviceCallback(audioCb, ui)
        ui.postDelayed({ audioReady = true }, 2500)

        applyMedia(controllers)
        refresh()
    }

    override fun onDestroy() {
        instance = null
        try { unregisterReceiver(sysReceiver) } catch (_: Exception) {}
        try { audio.unregisterAudioDeviceCallback(audioCb) } catch (_: Exception) {}
        try { wm.removeView(island) } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onInterrupt() {}

    // ---------- sistem: volume, baterai ----------
    private val sysReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                "android.media.VOLUME_CHANGED_ACTION" -> onVolume(i)
                Intent.ACTION_POWER_CONNECTED -> showTemp("pwr", null, "🔌 Mengisi daya ${battery()}%", battery(), 2500)
                Intent.ACTION_POWER_DISCONNECTED -> showTemp("pwr", null, "🔋 ${battery()}% · daya dilepas", battery(), 2000)
                Intent.ACTION_BATTERY_LOW -> showTemp("low", null, "🪫 Baterai lemah ${battery()}%", battery(), 4000)
            }
        }
    }

    private fun battery(): Int {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val s = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (s > 0) l * 100 / s else 0
    }

    private fun onVolume(i: Intent) {
        if (i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1) != AudioManager.STREAM_MUSIC) return
        val v = i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_VALUE", 0)
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val pct = if (max > 0) v * 100 / max else 0
        val txt = (if (pct == 0) "🔇 " else "🔊 ") + "$pct%"
        val view = tempView
        if (currentKey == "vol" && view != null) {
            view.findViewWithTag<ProgressBar>("bar")?.progress = pct
            view.findViewWithTag<TextView>("txt")?.text = txt
            scheduleTempClear(2000)
        } else showTemp("vol", null, txt, pct, 2000)
    }

    // ---------- earphone ----------
    private val headTypes = setOf(
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
        AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_USB_HEADSET
    )
    private val audioCb = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(d: Array<out AudioDeviceInfo>) {
            if (!audioReady) return
            d.firstOrNull { it.isSink && it.type in headTypes }
                ?.let { showTemp("hp", null, "🎧 ${it.productName} terhubung", -1, 2500) }
        }
        override fun onAudioDevicesRemoved(d: Array<out AudioDeviceInfo>) {
            if (!audioReady) return
            d.firstOrNull { it.isSink && it.type in headTypes }
                ?.let { showTemp("hp", null, "🎧 ${it.productName} terputus", -1, 2000) }
        }
    }

    // ---------- app berjalan ----------
    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg == lastPkg) return
        if (pkg.startsWith("com.android.systemui") || pkg.contains("inputmethod") || pkg.contains("keyboard")) return
        lastPkg = pkg
        if (tempView != null && tempKey != "app") return
        val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
        showTemp("app", appIcon(pkg), label, -1, 1500)
    }

    // ---------- notifikasi ----------
    fun onNotif(sbn: StatusBarNotification) {
        val n = sbn.notification
        if (sbn.packageName == packageName) return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val isCall = n.category == Notification.CATEGORY_CALL
        val ex = n.extras
        if (sbn.isOngoing && !isCall) {
            // aktivitas langsung: unduhan, pengiriman, dll yang punya progres
            if (ex.getInt(Notification.EXTRA_PROGRESS_MAX) > 0 && n.category != Notification.CATEGORY_TRANSPORT &&
                !ex.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE)) ui.post { onLive(sbn) }
            return
        }
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        ui.post { if (!replying) showNotif(sbn, title, text, isCall) }
    }

    fun onNotifRemoved(sbn: StatusBarNotification) {
        ui.post { if (live?.key == sbn.key) { live = null; liveView = null; refresh() } }
    }

    private fun showNotif(sbn: StatusBarNotification, title: String, text: String, isCall: Boolean) {
        val acts = sbn.notification.actions?.toList().orEmpty()
        val reply = acts.firstOrNull { it.remoteInputs?.isNotEmpty() == true }
        val v = row(appIcon(sbn.packageName), if (text.isBlank()) title else "$title: $text", -1) as LinearLayout
        v.setOnClickListener { openNotif(sbn) }
        if (reply != null) v.addView(tapBtn("Balas", 13f) { startReply(sbn, reply) })
        else acts.filter { it.actionIntent != null && it.remoteInputs.isNullOrEmpty() }
            .take(if (isCall) 2 else 1)
            .forEach { a -> v.addView(tapBtn(a.title.toString(), 13f) { fire(a.actionIntent); dismissTemp() }) }
        val ms = if (isCall) 25_000L else if (reply != null) 7000L else 4000L
        showTemp((if (isCall) "call:" else "notif:") + sbn.key + ":" + sbn.postTime, null, "", -1, ms, v)
    }

    private fun onLive(sbn: StatusBarNotification) {
        val ex = sbn.notification.extras
        val pct = ex.getInt(Notification.EXTRA_PROGRESS) * 100 / ex.getInt(Notification.EXTRA_PROGRESS_MAX)
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val same = live?.key == sbn.key
        live = sbn
        val v = liveView
        if (same && v != null && currentKey == "live:${sbn.key}") {
            v.findViewWithTag<ProgressBar>("bar")?.progress = pct
            v.findViewWithTag<TextView>("txt")?.text = "$title · $pct%"
        } else refresh()
    }

    private fun fire(pi: PendingIntent) {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                val o = ActivityOptions.makeBasic()
                o.setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
                pi.send(this, 0, null, null, null, null, o.toBundle())
            } else pi.send()
        } catch (_: Exception) {}
    }

    private fun openNotif(sbn: StatusBarNotification) {
        val pi = sbn.notification.contentIntent
        if (pi != null) fire(pi) else try {
            packageManager.getLaunchIntentForPackage(sbn.packageName)?.let { it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(it) }
        } catch (_: Exception) {}
        dismissTemp()
    }

    private fun dismissTemp() { ui.removeCallbacks(tempClear); tempView = null; refresh() }

    // ---------- balas dari pulau ----------
    private fun setFocusable(on: Boolean) {
        lp.flags = if (on) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        try { wm.updateViewLayout(island, lp) } catch (_: Exception) {}
    }

    private fun startReply(sbn: StatusBarNotification, action: Notification.Action) {
        replying = true
        ui.removeCallbacks(tempClear)
        tempView = replyView(sbn, action); tempKey = "reply:${sbn.key}"
        refresh()
        ui.postDelayed({
            setFocusable(true)
            tempView?.findViewWithTag<EditText>("edit")?.let {
                it.requestFocus()
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(it, InputMethodManager.SHOW_IMPLICIT)
            }
        }, 350)
    }

    private fun closeReply(sent: Boolean) {
        replying = false
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(island.windowToken, 0)
        setFocusable(false)
        tempView = null
        if (sent) showTemp("sent", null, "✓ Terkirim", -1, 1500) else refresh()
    }

    private fun sendReply(action: Notification.Action, text: String) {
        try {
            val inputs = action.remoteInputs ?: return
            val results = Bundle()
            for (r in inputs) results.putCharSequence(r.resultKey, text)
            val intent = Intent()
            RemoteInput.addResultsToIntent(inputs, intent, results)
            action.actionIntent.send(this, 0, intent)
            closeReply(true)
        } catch (_: Exception) { closeReply(false) }
    }

    private fun replyView(sbn: StatusBarNotification, action: Notification.Action): View {
        val ex = sbn.notification.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val edit = EditText(this).apply {
            tag = "edit"; hint = "Balas $title…"
            setHintTextColor(0x99FFFFFF.toInt()); setTextColor(Color.WHITE); textSize = 14f
            setSingleLine(); imeOptions = EditorInfo.IME_ACTION_SEND
            background = GradientDrawable().apply { setColor(0x22FFFFFF); cornerRadius = dp(18).toFloat() }
            setPadding(dp(14), dp(6), dp(14), dp(6))
        }
        val send = { val t = edit.text.toString().trim(); if (t.isNotEmpty()) sendReply(action, t) }
        edit.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEND) { send(); true } else false }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(10), dp(10), dp(8))
            addView(label(title, 13f).apply { setTypeface(null, Typeface.BOLD) })
            addView(label(text, 12f).apply { alpha = 0.8f })
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(edit, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                addView(tapBtn("➤", 20f) { send() })
                addView(tapBtn("✕", 16f) { closeReply(false) })
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        }
    }

    // ---------- musik ----------
    fun refreshMedia() { ui.post { applyMedia(controllers) } }

    private val mediaCb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) { refresh() }
        override fun onMetadataChanged(metadata: MediaMetadata?) { refresh() }
    }

    private fun applyMedia(list: List<MediaController>) {
        media?.unregisterCallback(mediaCb)
        media = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull()
        media?.registerCallback(mediaCb)
        refresh()
    }

    private fun isPlaying() = media?.playbackState?.state == PlaybackState.STATE_PLAYING
    private fun songTitle() = media?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty()
    private fun songLine(): String {
        val t = songTitle()
        val a = media?.metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST).orEmpty()
        return if (a.isBlank()) t else "$t – $a"
    }
    private fun albumArt(): Drawable? =
        media?.metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)?.let { BitmapDrawable(resources, it) }

    // ---------- timer & progres ----------
    private val ticker = object : Runnable {
        override fun run() {
            var again = false
            if (timerEnd != 0L) {
                val left = timerEnd - SystemClock.elapsedRealtime()
                if (left <= 0) { timerEnd = 0; timerLabel = null; panelTimerLabel = null; timerDone() }
                else {
                    val s = (left + 999) / 1000
                    val t = "⏱ %02d:%02d".format(s / 60, s % 60)
                    timerLabel?.text = t; panelTimerLabel?.text = t
                    again = true
                }
            }
            progressBar?.let { pb ->
                val st = media?.playbackState
                val dur = media?.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
                if (st != null && dur > 0) {
                    var pos = st.position
                    if (st.state == PlaybackState.STATE_PLAYING)
                        pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
                    pb.progress = (pos * 1000 / dur).coerceIn(0L, 1000L).toInt()
                }
                if (expanded) again = true
            }
            if (again) ui.postDelayed(this, 500)
        }
    }

    private fun kick() { ui.removeCallbacks(ticker); ui.post(ticker) }

    private fun startTimer(min: Int) {
        timerEnd = SystemClock.elapsedRealtime() + min * 60_000L
        refresh(); kick()
    }

    private fun stopTimer() { timerEnd = 0; ui.removeCallbacks(ticker); refresh() }

    private fun timerDone() {
        try {
            getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createOneShot(800, VibrationEffect.DEFAULT_AMPLITUDE))
            RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)).play()
        } catch (_: Exception) {}
        showTemp("done", null, "⏰ Timer selesai!", -1, 5000)
    }

    // ---------- tampilan ----------
    private fun toggleExpanded() {
        if (replying) return
        expanded = !expanded
        ui.removeCallbacks(autoCollapse)
        if (expanded) ui.postDelayed(autoCollapse, 10_000)
        refresh()
    }
    private val autoCollapse = Runnable { expanded = false; refresh() }

    private val tempClear = Runnable { tempView = null; refresh() }
    private fun scheduleTempClear(ms: Long) { ui.removeCallbacks(tempClear); ui.postDelayed(tempClear, ms) }

    private fun showTemp(key: String, icon: Drawable?, text: String, progress: Int, ms: Long, custom: View? = null) {
        if (replying && !key.startsWith("reply")) return
        tempView = custom ?: row(icon, text, progress)
        tempKey = key
        scheduleTempClear(ms)
        refresh()
    }

    private fun refresh() {
        val timerOn = timerEnd > SystemClock.elapsedRealtime()
        val music = isPlaying() && songTitle().isNotBlank()
        val key: String
        val view: View
        val w: Int
        val h: Int
        when {
            tempView != null -> {
                key = tempKey; view = tempView!!
                if (key.startsWith("reply")) { w = dp(340); h = dp(124) }
                else if (key.startsWith("call:")) { w = dp(340); h = dp(48) }
                else if (key.startsWith("notif:")) { w = dp(310); h = dp(48) }
                else { w = dp(260); h = dp(44) }
            }
            expanded -> {
                key = "panel:${songTitle()}:${isPlaying()}:$timerOn"
                if (key == currentKey) return
                view = panel(); w = dp(340); h = dp(196)
            }
            music -> {
                key = "music:${songLine()}:$timerOn"
                if (key == currentKey) return
                view = musicRow(timerOn); w = if (timerOn) dp(320) else dp(260); h = dp(44)
            }
            timerOn -> {
                key = "timer"
                if (key == currentKey) return
                view = row(null, "⏱ --:--", -1)
                timerLabel = view.findViewWithTag("txt")
                w = dp(150); h = dp(40)
            }
            live != null -> {
                val s = live!!
                key = "live:${s.key}"
                if (key == currentKey) return
                val ex = s.notification.extras
                val max = ex.getInt(Notification.EXTRA_PROGRESS_MAX).coerceAtLeast(1)
                val pct = ex.getInt(Notification.EXTRA_PROGRESS) * 100 / max
                val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
                view = row(appIcon(s.packageName), "$title · $pct%", pct)
                view.setOnClickListener { openNotif(s) }
                liveView = view
                w = dp(270); h = dp(44)
            }
            else -> {
                key = "idle"
                if (key == currentKey) return
                view = EyesView(this); w = dp(110); h = dp(32)
            }
        }
        if (key == currentKey && tempView != null) return
        currentKey = key
        glass.tintTo(if (key == "idle") GlassDrawable.LIGHT else GlassDrawable.DARK)
        island.removeAllViews()
        island.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        view.alpha = 0f
        view.animate().alpha(1f).setDuration(200).start()
        morph(w, h)
        if (timerOn || expanded) kick()
    }

    private fun morph(w: Int, h: Int) {
        sizeAnim?.cancel()
        val w0 = lp.width; val h0 = lp.height
        sizeAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 300
            interpolator = OvershootInterpolator(0.9f)
            addUpdateListener {
                val t = it.animatedValue as Float
                lp.width = (w0 + (w - w0) * t).toInt()
                lp.height = (h0 + (h - h0) * t).toInt()
                try { wm.updateViewLayout(island, lp) } catch (_: Exception) {}
            }
            start()
        }
    }

    private fun appIcon(pkg: String): Drawable? = try { packageManager.getApplicationIcon(pkg) } catch (_: Exception) { null }

    private fun row(icon: Drawable?, text: String, progress: Int): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(12), 0, dp(14), 0)
        if (icon != null) addView(ImageView(context).apply { setImageDrawable(icon) },
            LinearLayout.LayoutParams(dp(26), dp(26)).apply { rightMargin = dp(10) })
        addView(TextView(context).apply {
            tag = "txt"; this.text = text; setTextColor(Color.WHITE); textSize = 13f
            setShadowLayer(4f, 0f, 1f, 0x66000000)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (progress >= 0) addView(ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal).apply {
            tag = "bar"; max = 100; this.progress = progress
            progressTintList = ColorStateList.valueOf(Color.WHITE)
            progressBackgroundTintList = ColorStateList.valueOf(0x33FFFFFF)
        }, LinearLayout.LayoutParams(dp(80), dp(6)).apply { leftMargin = dp(8) })
    }

    private fun musicRow(timerOn: Boolean): View = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(10), 0, dp(14), 0)
        val art = albumArt()
        if (art != null) addView(ImageView(context).apply { setImageDrawable(art) },
            LinearLayout.LayoutParams(dp(28), dp(28)).apply { rightMargin = dp(10) })
        else addView(label("♪", 16f), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(10) })
        addView(label(songLine(), 13f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (timerOn) {
            val t = label("⏱ --:--", 12f).apply { tag = "txt" }
            timerLabel = t
            addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) })
        }
        addView(EqView(context), LinearLayout.LayoutParams(dp(22), dp(18)).apply { leftMargin = dp(10) })
    }

    private fun label(t: String, size: Float = 14f) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.WHITE)
        setShadowLayer(4f, 0f, 1f, 0x66000000)
        maxLines = 1; ellipsize = TextUtils.TruncateAt.END
    }

    private fun tapBtn(t: String, size: Float = 22f, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(14), dp(6), dp(14), dp(6))
        background = InsetDrawable(GradientDrawable().apply { setColor(0x22FFFFFF); cornerRadius = dp(18).toFloat() }, dp(3))
        setOnClickListener { onClick() }
    }

    private fun panel(): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(14), dp(18), dp(10))
        addView(label(if (songTitle().isBlank()) "♪ Tidak ada musik" else "♪ ${songLine()}"))
        val pb = ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progressTintList = ColorStateList.valueOf(Color.WHITE)
            progressBackgroundTintList = ColorStateList.valueOf(0x33FFFFFF)
        }
        progressBar = pb
        addView(pb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(4)).apply { topMargin = dp(8) })
        addView(LinearLayout(context).apply {
            gravity = Gravity.CENTER
            addView(tapBtn("⏮") { media?.transportControls?.skipToPrevious() })
            addView(tapBtn(if (isPlaying()) "⏸" else "▶", 26f) {
                if (isPlaying()) media?.transportControls?.pause() else media?.transportControls?.play()
            })
            addView(tapBtn("⏭") { media?.transportControls?.skipToNext() })
        })
        val tl = label(if (timerEnd > SystemClock.elapsedRealtime()) "⏱ --:--" else "⏱ Timer", 13f)
        panelTimerLabel = tl
        addView(tl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        addView(LinearLayout(context).apply {
            gravity = Gravity.CENTER
            for (m in intArrayOf(1, 5, 10)) addView(tapBtn("${m}m", 15f) { startTimer(m) })
            addView(tapBtn("Stop", 15f) { stopTimer() })
        })
    }
}

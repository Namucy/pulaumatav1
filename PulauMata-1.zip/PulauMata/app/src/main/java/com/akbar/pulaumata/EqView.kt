package com.akbar.pulaumata

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.view.View
import kotlin.random.Random

/** Batang equalizer kecil yang bergerak saat musik diputar. */
class EqView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeCap = Paint.Cap.ROUND }
    private val hs = FloatArray(4) { 0.4f }
    private val h = Handler(Looper.getMainLooper())
    private val loop = object : Runnable {
        override fun run() {
            for (i in hs.indices) hs[i] = 0.25f + Random.nextFloat() * 0.75f
            invalidate(); h.postDelayed(this, 160)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); h.post(loop) }
    override fun onDetachedFromWindow() { h.removeCallbacks(loop); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val bw = width / (hs.size * 2 - 1f)
        p.strokeWidth = bw
        for (i in hs.indices) {
            val x = bw / 2 + i * 2 * bw
            val ch = height * hs[i]
            c.drawLine(x, (height + ch) / 2, x, (height - ch) / 2, p)
        }
    }
}
